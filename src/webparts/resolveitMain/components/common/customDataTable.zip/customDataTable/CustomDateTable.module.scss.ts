/* tslint:disable */
require("./CustomDateTable.module.css");
const styles = {
  formTitle: 'formTitle_49dbc9fe',
  popupWrapper: 'popupWrapper_49dbc9fe',
  actionBtns: 'actionBtns_49dbc9fe'
};

export default styles;
/* tslint:enable */